import UIKit

let startTime = CFAbsoluteTimeGetCurrent()
DispatchQueue.global().sync {
    for i in 0...10 {
        print("Fui....\(i)")
    }
}
DispatchQueue.global().sync {
    for i in 0...10 {
        print("Voltei....\(i)")
    }
}

func fetchUserId (from server: String) async -> Int {
    if server == "primary"{
        return 97
    }
    return 500
}

func  fetchUserName(from server: String) async -> String {
    let userId = await fetchUserId(from: server)
    if userId == 500 {
        return "Gabriel"
    }
    return "Convidado"
}

func connectUser(to server: String) async {
    async let userId = fetchUserId(from: server)
    async let username = fetchUserName(from: server)
    let greeting = await "Olá, \(username)! Bem vindo de volta. Seu user ID é: \(userId)."
}

Task {
    await connectUser(to: "primary")
}

let gallery = [
    "SummerVacation": ["praia.png", "roma.png", "rio.png", "china.png", "portugal.png", "madrid.png", "tailandia.png"],
    "RoadTrip": ["paris.png", "chile.png", "mexico.png", "argentina.png"]
]

func listPhotos(inGallery name: String) async -> [String] {
    //simulattion async network
    do {
        try await Task.sleep(until: .now + .seconds(2), clock: .continuous)
    } catch {}
    return gallery[name] ?? []
}

