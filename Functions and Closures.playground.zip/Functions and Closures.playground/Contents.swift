import UIKit

func greet(person: String, day: String) -> String{
    return "Olá \(person), hoje é \(day)"
}

greet(person: "Gabriel", day: "Quinta-Feira")

func greet(_ person: String, _ day: String) -> String{
    return "Olá \(person), hoje é \(day)"
}
greet("José", "quarta-feira")

func calculateStatistics(scores: [Int]) -> (min: Int, max: Int, sum: Int){
    var min = scores[0]
    var max = scores[0]
    var sum = 0
    
    for score in scores{
        if score > max {
            max = score
        } else if score < min {
            min = score
        }
        sum += score
    }
    
    return (min, max, sum)
}

let statistics = calculateStatistics(scores: [3,45,86,9,8,76554,665,43])

print(statistics.sum)
print(statistics.2)
print(statistics.0)
print(statistics.1)

func returnFifteen() -> Int{
    var y = 10
    
    func add(){
        y += 5
    }
    add()
    return y
}
returnFifteen()

func makeIncrementer() -> ((Int) -> Int) {
    func addOne (number: Int) -> Int{
        return 1 + number
    }
    return addOne
}
var increment = makeIncrementer()
increment(90)

