import UIKit

//Enums
enum Rank: Int {
    case ace = 1
    case two, tree, four, five, six, seven, eight, nine, ten
    case jack, queen, king
    
    func simpleDescription() -> String{
        switch self{
        case .ace:
            return "ace"
        case . jack:
            return "jack"
        case .queen:
            return "Queen"
        case .king:
            return "King"
        default:
            return String(self.rawValue)
        }
    }
}
let ace = Rank.ace
let aceRawValue = ace.rawValue

enum Suit {
    case spades, hearts, diamonds, clubs
    
    func simpleDescription() -> String {
        switch self {
        case .spades:
            return "Spades"
        case . hearts:
            return "Hearts"
        case .diamonds:
            return "Diamonds"
        case .clubs:
            return "Clubes"
        }
    }
}
let hearts = Suit.hearts
let heartsDescription = hearts.simpleDescription()


//Struct

struct Card{
    var rank: Rank
    var suit: Suit
    
    func simpleDescription() -> String {
        return "O \(rank.simpleDescription()) do \(suit.simpleDescription())"
    }
}
let treeSpades = Card(rank: .tree, suit: .spades)
let aceSpades = Card(rank: .ace, suit: .spades)
let aceSpadesDescription = aceSpades.simpleDescription()
