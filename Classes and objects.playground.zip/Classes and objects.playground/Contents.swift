import UIKit

class Shape{
    var numberOfSides = 0
    func simpleDescription() -> String{
        return "Uma forma com \(numberOfSides) lados."
    }
}

var shape = Shape()
shape.numberOfSides = 3
var shapeDescription = shape.simpleDescription()
print(shapeDescription)

class NameShape{
    var numberOfSide: Int = 0
    var name: String
    
    init (name: String){
        self.name = name
    }
    
    func simpleDescription() -> String{
        return "Outra forma com \(numberOfSide) lados."
    }
}

class Square: NameShape{
    var sideLegnth: Double
    
    init(sideLenght: Double, name: String) {
        self.sideLegnth = sideLenght
        super.init(name: name)
        numberOfSide = 4
    }
    
    func areaCalc() -> Double{
        return sideLegnth * sideLegnth
    }
    
    override func simpleDescription() -> String {
        return "Um quadrdado com comprimento de: \(sideLegnth)"
    }
}
