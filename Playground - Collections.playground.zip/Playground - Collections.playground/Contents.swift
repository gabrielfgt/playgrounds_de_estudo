import UIKit

var someInts: [Int] = []
print("someItens é do tipo [Int] com \(someInts) itens.")

someInts.append(3)

var trheeDoubles = Array(repeating: 0.0, count: 3)

var anotherTreeDoubles = Array(repeating: 2.5, count: 3)
var sixDoubles = trheeDoubles + anotherTreeDoubles

var shoppinList: [String] = ["Ovos","Leite"]
print("A lista de compras contem \(shoppinList.count) itens.")

shoppinList.append("Farinha")
print("A lista agora tem \(shoppinList).")
print("No total agora são \(shoppinList.count) itens.")
print("O primeiro item é \(shoppinList.first).")
print("O ultimo item é \(shoppinList.last).")
print("A lista suporta \(shoppinList.capacity).")
shoppinList[0...2] = ["maças","bananas"]
print(shoppinList)


var letters = Set<Character>()
letters.insert("A")
print(letters)

var favoriteGenres: Set<String> = ["Rock", "Rap","Bossa-Nova"]
print (favoriteGenres)
print (favoriteGenres.count)

if favoriteGenres.contains("Funk"){
    print("Genero enconrtado")
} else {print("Nao encontrado na lista.")}

let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8, 10]
let singleDigitsPrimeNumber: Set = [2, 3, 5, 7]
oddDigits.union(evenDigits).sorted()
print(oddDigits)
var teste1 = oddDigits.union(evenDigits).count
print(oddDigits)
oddDigits.intersection(evenDigits).sorted()
oddDigits.subtracting(evenDigits).sorted()
oddDigits.symmetricDifference(singleDigitsPrimeNumber).sorted()
singleDigitsPrimeNumber.isSubset(of: singleDigitsPrimeNumber)
singleDigitsPrimeNumber.isSuperset(of: oddDigits)
evenDigits.isDisjoint(with: singleDigitsPrimeNumber)
