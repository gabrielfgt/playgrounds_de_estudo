import UIKit

//Optional chainings
class Residence{
    var numberOfRooms = 4
}
class Person{
    var redicence: Residence?
}

let joao = Person()
joao.redicence?.numberOfRooms
if let roomCount = joao.redicence?.numberOfRooms{
    print("A residencia do João tem \(roomCount) quartos.")
}   else{
        print("Nao foi possivel verificar o numero de quartos.")
    }

joao.redicence = Residence()
if let roomCount = joao.redicence?.numberOfRooms{
    print("A residencia do João tem \(roomCount) quartos.")
}   else{
        print("Nao foi possivel verificar o numero de quartos.")
    }
