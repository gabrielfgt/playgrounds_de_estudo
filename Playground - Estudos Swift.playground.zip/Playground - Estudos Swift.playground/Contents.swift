import UIKit

//Valores simples
var greeting = "Hello, playground"
greeting = "Olá, mundo!"
let despedida = "Até logo."

print(greeting, despedida)

var myVariable = 45
myVariable = 89

let myConstant = 30
let implicitInt = 50
let explicitInt: Int = 12

let label = "A largura é"
let width = 94
let widthLabel = label + String(width)

let apple = 3
let orange = 5

//interpolacao
let appleSummary = "Eu tenho \(apple) maçãs."
let fruitSummary = "Eu tenho \(apple + orange) frutas."

//Quotes

let quotation = """
Este é um modelo de texto que está escrito em várias linhas."
Um treino para o modelo de string usado nesta cosntante"
"""

//Arrays
var fruits = ["oranges", "apples", "pineaples", "lemon"]
fruits[1] = "mellon"
var occupations = [
    "Joao" : "Engenheiro",
    "Pedro" : "Desing"
]
occupations["Maria"] = "Relacoes Publicas"

fruits.append("Blackberry")
print(fruits)
print(occupations)



