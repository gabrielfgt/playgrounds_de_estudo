import UIKit

let individulaScores = [75, 103, 45, 89, 37]
var teamScore = 0
for score in individulaScores {
    if score > 50{
        teamScore += 3
    } else {
        teamScore += 1
    }
}
print(teamScore)

var optionalString: String? = "Olá!"
print(optionalString == nil)
print(optionalString)

var optionalName: String? = "Gabriel Francisco"
var greeting = "Olá"

if let name = optionalName{
    greeting = "Olá, \(name)"
}

var nickname: String? = nil
var fullName: String = "Gabriel Teixeira"
let informalGreeting = "Oi \(nickname ?? fullName)"
var nickname2: String? = "Ga"
var fullName2: String = "Gabriel Teixeira"
let informalGreeting2 = "Oi \(nickname2 ?? fullName2)"

let vegetables = "pimentao vermelho"
switch vegetables{
case "Salsão":
    print("adicione este ingrediente")
case "Pepino":
    print("melhor nao adicionar este")
case let x where x.hasPrefix("pimentao"):
    print ("É bom \(x)?")
default:
    print("Tudo vai bem na sopa!")
}


//Arrays
let interestingNumber = [
    "Melhor":[2, 3, 5, 7, 11, 13],
    "Fibinacci": [1, 1, 2, 3, 5, 8],
    "Quadrado": [1, 4, 9, 16, 25],
]
var largest = 0
for(_, numbers) in interestingNumber{
    for number in numbers{
        if number > largest{
            largest = number
        }
    }
}
print(largest)


var n = 2
while n < 100{
    n *= 2
}
print(n)

var m = 2
repeat{
    m *= 2
}while m < 100
print(m)

var total = 0
for i in 0..<4{
    total += i
}
print(total)
